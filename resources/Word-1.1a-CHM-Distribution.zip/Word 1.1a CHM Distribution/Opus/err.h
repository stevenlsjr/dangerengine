THIS FILE IS OBSOLETE

#ifdef REMOVE


/* err.h -- error numbers for opus */

#define errNoError		0
#define errCantOpenFile		1
#define errBadFileName		2
#define errCantCreateDoc	3
#define errCantOpenDoc		4
#define errStringTooBig		5
#define errNoMemory		6
#define errOutOfRange		7
#define errNeedsDoc		8
#define errBookmarkNotFound	9
#define errCantFindDoc		10
#define errBadParam		11
#define errBadName		12
#define errBadSearchString	13
#define errCannotInitiate       14
#define errBogusDcl	    	15
#define errNoResponse   	16
#define errAppNacked	    	17
#define errNoSuchWin	    	18
#define errCantActivate	    	19
#define errCannotSendKeys   	20

#define errMax			21


#endif /* REMOVE */
