/* V A R S . C */

/* Note:  this file is #included into win.c */

/* globals */

/*      G   L   O   B   A   L   S       */

/* A L L O C A T I O N */

/* F O R M A T T I N G */
/* F E T C H  &  C A C H E S */

/* I N S E R T */


/* F O N T S */


/* W I N D O W S */


/* F I L E S */


/* D O C S */



/* F I E L D S */


/* P R I N T  M E R G E */


/* C L I P B O A R D */




/* D D E */

/* D I S P L A Y */
/* S E L E C T */



/* S C C */



/* S T Y L E S  */

/* M A I N */


/* C M D  &  U N D O  */



/* M E N U S */



/* R U L E R */

/* R I B B O N */

/* S T A T U S  L I N E */

/* S C R A P */

/* L A Y O U T   A N D   P R I N T */
/* P I C T U R E S */


/* S P R M S */

/* M - S  W I N D O W S */


/* K E Y B O A R D */


/* M O U S E */

/* C H A R A C T E R S */



/* U N C L A S S I F I E D  F L A G S */



/* P R O M P T */



/* D E B U G */

/* S T R I N G S */



/* P R O C E D U R E  T H U N K  P O I N T E R S */




/* K E Y  M A P  A N D  C O M M A N D  T A B L E  V A R I A B L E S */



/* C O M M A N D  R E C O R D E R */



/* S A V E   O P E N   A N D   D E L E T E */

#ifdef MAC
/* vfnKeepInMem is set when we want an fn loaded into the file cache
in background */
int             vfnKeepInMem = fnNil;
/* vpnKeepNext is the number of next pn of vfnKeepInMem
to be checked for reading into file cache */
PN              vpnKeepNext;

int     scnCur;        /* Temporary, until we port the new PRINTSUB.C */

#endif /* MAC */



/* C A  A D J U S T */


/* R E S O U R C E S */



/* M E M O R Y  M A N A G E M E N T */



/*  D O C U M E N T  R E T R I E V A L  */


/* M A T H  P A C K */

/* F I N D  N E X T */



/*  H E L P  */



/* E N V I R O N M E N T */

