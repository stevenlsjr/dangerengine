Directory contents:

Opus\...
This contains the source code as it existed on January 10, 1991.  This represents the sources code used to build Word for Windows 1.1a, codenamed "Opus".  All of the tools used to build the sources should also in the Opus hierarchy. The product development team was able to build the product on MS-DOS as well as OS/2 (likely version 1.3x of OS/2).  Most of the source code was built with a proprietary "csl" compiler that generated "pcode" that was run through an interpreter at runtime. 

OpusProg\...
Some of the final product distribution is under this directory -- namely the techref documents as well as the readme documents.

OpusEtAl\...
This was a support project used by the product team. It contains architecture and technical documentation for the code as well as source code for many of the custom tools used in the Opus project for building the source code.
